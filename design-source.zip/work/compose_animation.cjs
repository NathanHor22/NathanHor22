const fs = require('node:fs');
const path = require('node:path');
// Run from the extracted design-source root. Install with: npm install sharp
let sharp;
try { sharp = require('sharp'); }
catch { sharp = require('C:/Users/damna/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'); }

(async () => {
  const bg = await sharp('outputs/assets/digimon-stage.svg').png().toBuffer();
  fs.mkdirSync('work/composited', {recursive:true});
  const preview = process.argv.includes('preview');
  const files = preview ? ['work/digimon-model-preview.png'] : fs.readdirSync('work/digimon-frames').filter(f => /^frame_\d+\.png$/.test(f)).sort().map(f=>'work/digimon-frames/'+f);
  if (!preview && files.length !== 72) throw new Error(`Expected 72 Blender frames, found ${files.length}`);
  for (let i=0;i<files.length;i++) {
    const model = await sharp(files[i]).resize(680,614).toBuffer();
    const out = preview ? 'outputs/selection-preview.png' : `work/composited/${String(i).padStart(3,'0')}.png`;
    await sharp(bg).composite([{input:model,left:490,top:0}]).png().toFile(out);
  }
  await sharp('outputs/assets/banner.svg').png().toFile('outputs/banner-preview.png');
  console.log(`Composited ${files.length} frame(s).`);
})();
