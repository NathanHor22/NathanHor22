from pathlib import Path
from PIL import Image, ImageOps, ImageDraw

paths = sorted(Path('work/composited').glob('*.png'))
assert len(paths) == 72, f'Expected 72 frames, got {len(paths)}'
frames = [Image.open(p).convert('RGB') for p in paths]
sample = Image.new('RGB', (1200, 660 * 7))
for row, index in enumerate((0, 6, 16, 27, 39, 51, 63)):
    sample.paste(frames[index], (0, row * 660))
palette = sample.quantize(colors=256, method=Image.Quantize.MEDIANCUT)
indexed = [frame.quantize(palette=palette, dither=Image.Dither.NONE) for frame in frames]
durations = [80, 80, 90] * 24
destination = Path('outputs/assets/digimon-select.gif')
indexed[0].save(destination, save_all=True, append_images=indexed[1:], loop=0,
                duration=durations, optimize=True, disposal=1)
frames[0].save('outputs/assets/digimon-still.png', optimize=True)

sheet = Image.new('RGB', (1200, 660), '#10151d')
for slot, index in enumerate((0, 12, 24, 36, 48, 60)):
    thumb = frames[index].resize((400, 220), Image.Resampling.LANCZOS)
    sheet.paste(thumb, ((slot % 3) * 400, (slot // 3) * 330))
    ImageDraw.Draw(sheet).text(((slot % 3) * 400 + 12, (slot // 3) * 330 + 240), f'FRAME {index+1:02d}', fill='#eaff4b')
sheet.save('work/turntable-contact-sheet.png')

with Image.open(destination) as check:
    assert check.n_frames == 72
    assert check.info.get('loop') == 0
    total_ms = 0
    for i in range(check.n_frames):
        check.seek(i)
        total_ms += check.info['duration']
    print(f'GIF: {check.n_frames} frames, {check.size}, {total_ms} ms, {destination.stat().st_size / 1024 / 1024:.2f} MiB, infinite loop.')
